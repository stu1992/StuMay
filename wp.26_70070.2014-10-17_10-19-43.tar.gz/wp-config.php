<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'stumysee_wp');

/** MySQL database username */
define('DB_USER', 'stumysee_wp');

/** MySQL database password */
define('DB_PASSWORD', 'NyH[S6-P02');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'nvmj2jru7kvvozv2c9rmpn8jmy9zzelof3b2efqyphoen67dcvpjbappmpgqwlk7');
define('SECURE_AUTH_KEY',  'bsfl90dt8srq3nqacwy00fmeahnpjnlyqzllz8kojbjyhgtovilemwceogi6l39v');
define('LOGGED_IN_KEY',    'm3axsrrxwn5me8uwib4jwobvn1w4gmdtxvhh3aswkmnf1dja9ara36jlwa064gya');
define('NONCE_KEY',        'kuefvblpi1bkxd3we1qg8z5ia2j1kwwnpuh9vjen3gcctgjnzih506twvbneyzkk');
define('AUTH_SALT',        'v8tyrpkb7fdjdchvp3uutxq4fayjgpcrhlr7ehdtxbu4siamigfkinlnw2vxpt3a');
define('SECURE_AUTH_SALT', 'kkte9atzu7rd0i08bo4yj8i3pqelkhdmdwesukkgo059dk81y1wk1uwyzhxtoi38');
define('LOGGED_IN_SALT',   'amqp8li1rhjgazdse3cufy4l7kaeogjjgmg1okdjnfeyds3odfbseclip8ohnfkw');
define('NONCE_SALT',       'vjwdtexdfnfepshvt35ivevujux7z20r0cpecyrhwm96urwl8g2otzq3vpuiiimh');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
